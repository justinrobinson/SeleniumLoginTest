﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace SeleniumTest1
{
    public class FirefoxTest
    {
        private IWebDriver _driver;

        /* todo: make abstract: http://powerdotnetcore.com/selenium/tip-2-basic-installation-of-selenium-webdriver-in-visual-studio-c-sharp */
        public FirefoxTest(IWebDriver driver)
        {
            if (driver == null)
                throw new ArgumentNullException("driver");
            _driver = driver;
        }

        public void SeleniumFirefoxTest1()
        {
            /* todo: check for nulls & 'Displayed' property */

            // Initialize webdriver  
            //IWebDriver webDriver = new FirefoxDriver();
            //IWebDriver driver = new FirefoxDriver();

            // Navigate by url to website
            // webDriver.Navigate().GoToUrl("https://www.bing.com");
            _driver.Navigate().GoToUrl("https://mail.yahoo.com");

            // diable/un-check checkbox
            IWebElement cbStayCheckedIn = _driver.FindElement(By.Id("persistent")) ??
                                          _driver.FindElement(By.ClassName(".persistent"));
            //IWebElement cbStayCheckedIn = webDriver.FindElement(By.ClassName(".persistent"));
            //if (cbStayCheckedIn == null)
            //{
            //    for (IWebElement checkbox : selectElements)
            //    {
            //        // uncheck 'em all
            //        if (checkbox.isSelected())
            //        {
            //            checkbox.click();
            //        }
            //    }
            //}
            if (cbStayCheckedIn != null && cbStayCheckedIn.Displayed && cbStayCheckedIn.Selected)
                cbStayCheckedIn.Click();

            //FirefoxWebElement cbStayCheckedIn;
            //cbStayCheckedIn 

            /* todo: add to constructor, if constructor-injection is working */
            // find search field
            IWebElement tbLogin = _driver.FindElement(By.Id("login-username")) ??
                                  _driver.FindElement(By.ClassName("login-input"));
            if (tbLogin == null)
                throw new Exception("Login Id and/or Class does not exist");

            // set "login text"
            tbLogin.SendKeys("justin.matomy@yahoo.com");

            /* todo: add to constructor, if constructor-injection is working */
            // find "Next/Submit button"
            IWebElement submitButton = _driver.FindElement(By.Id("login-signin")) ??
                                       _driver.FindElement(By.ClassName("mbr-buton-primary"));
            if (submitButton == null)
                throw new Exception("Next button does not exist");

            // click "Next/Submit button"
            submitButton.Click();

            // pause, just in case
            /* todo: change this to 5-6 seconds (?) */
            Thread.Sleep(4000);

            /* todo: add to constructor, if constructor-injection is working */
            /* todo: move this up and refactor */
            // find "password text"
            IWebElement tbPassword = _driver.FindElement(By.Id("login-passwd")) ??
                                  _driver.FindElement(By.ClassName("login-input"));
            if (tbPassword == null)
                throw new Exception("Password Id and/or Class does not exist");

            // set "password text"
            tbPassword.SendKeys("Testing@123");

            // find "Submit/Login button"
            IWebElement loginButton = _driver.FindElement(By.Id("login-signin")) ??
                                       _driver.FindElement(By.ClassName("mbr-buton-primary"));
            if (loginButton == null)
                throw new Exception("Login/Sign-In button does not exist");

            // click "login button"
            loginButton.Click();

            Console.ReadLine();
        }


        // no longer used (?)
        public void CheckBoxHelper(IWebElement ffCheckBox, bool clickCheckBox = false)
        {
            if (ffCheckBox == null || !ffCheckBox.Displayed) return;

            bool checkstatus = ffCheckBox.Selected; 
            if (checkstatus && clickCheckBox)
            {
                ffCheckBox.Click();
                Console.WriteLine("Checked the checkbox");
            }
            else
            {
                Console.WriteLine("Checkbox is already checked");
            }
        }

        public void CheckBoxHelper(FirefoxWebElement ffCheckBox, bool clickCheckBox = false)
        {
            if (ffCheckBox == null || !ffCheckBox.Displayed) return;

            bool checkstatus = ffCheckBox.Selected;
            if (checkstatus && clickCheckBox)
            {
                ffCheckBox.Click();
                Console.WriteLine("Checked the checkbox");
            }
            else
            {
                Console.WriteLine("Checkbox is already checked");
            }
        }

    }
}
